package com.example.cse227ca1prep

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlin.math.sign

class Login : AppCompatActivity() {
    lateinit var email : EditText
    lateinit var password : EditText
    lateinit var login : Button
    lateinit var signupText : TextView
    lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        login = findViewById(R.id.button)
        email = findViewById(R.id.editTextTextEmailAddress)
        password = findViewById(R.id.editTextTextPassword)
        signupText = findViewById(R.id.textView)
        auth = FirebaseAuth.getInstance()
        login.setOnClickListener(){
            if (email.text.toString().isEmpty() || password.text.toString().isEmpty()){
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show()
            }
            else{
                auth.signInWithEmailAndPassword(email.text.toString(), password.text.toString()).addOnCompleteListener {
                    if(it.isSuccessful){
                        Toast.makeText(this, "Login SuccessFull", Toast.LENGTH_SHORT).show()
                    }
                    else{
                        Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        signupText.setOnClickListener(){
            val intent = Intent(this, SignUp::class.java)
            startActivity(intent)
            finish()
        }
    }
}
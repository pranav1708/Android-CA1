package com.example.cse227ca1prep

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class SignUp : AppCompatActivity() {
    lateinit var auth : FirebaseAuth
    lateinit var mailID : EditText
    lateinit var pass : EditText
    lateinit var cPass : EditText
    lateinit var signup : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        auth = FirebaseAuth.getInstance()
        mailID = findViewById(R.id.editTextTextEmailAddress2)
        pass = findViewById(R.id.editTextTextPassword2)
        cPass = findViewById(R.id.editTextTextPassword3)
        signup = findViewById(R.id.button2)
        signup.setOnClickListener(){
            if(mailID.text.toString().isEmpty() || pass.text.toString().isEmpty() || cPass.text.toString().isEmpty()){
                Toast.makeText(this, "Enter all the fields", Toast.LENGTH_SHORT).show()
            }
            else if(pass.text.toString()!=cPass.text.toString()){
                Toast.makeText(this, "Password doesn't match", Toast.LENGTH_SHORT).show()
            }
            else{
                auth.createUserWithEmailAndPassword(mailID.text.toString(), pass.text.toString()).addOnCompleteListener {
                    if (it.isSuccessful){
                        Toast.makeText(this, "Signup Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, Login::class.java)
                        startActivity(intent)
                        finish()
                    }
                    else{
                        Toast.makeText(this, "SignUp failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}